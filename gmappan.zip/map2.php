<!DOCTYPE html >
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>Using MySQL and PHP with Google Maps</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>

<html>
  <body>
  
    <div class="row">

    <div class="large-12 columns">
      <div class="panel">
        <h5>Find a Location</h5>
        <div>
         <input type="text" id="addressInput" size="10"/>
        <select id="radiusSelect">
          <option value="25" selected>25mi</option>
          <option value="100">100mi</option>
          <option value="200">200mi</option>
        </select>
        <input type="button" onclick="searchLocations()" value="Search"/>
        </div>
        <div><select id="locationSelect" style="width:100%;visibility:hidden"></select></div>
        <div id="map" style="width: 100%; height: 500px"></div>
      </div>
    </div>

    </div>
          
          
    <div id="map"></div>

    <script>
      var customLabel = {
        restaurant: {
          label: 'R'
        },
        bar: {
          label: 'B'
        }
      };
            
    /*         function searchLocations() {
     var address = document.getElementById("addressInput").value;
     var geocoder = new google.maps.Geocoder();
     geocoder.geocode({address: address}, function(results, status) {
       if (status == google.maps.GeocoderStatus.OK) {
        searchLocationsNear(results[0].geometry.location);
       } else {
         alert(address + ' not found');
       }
     });
   }

   function clearLocations() {
     infoWindow.close();
     for (var i = 0; i < markers.length; i++) {
       markers[i].setMap(null);
     }
     markers.length = 0;

     locationSelect.innerHTML = "";
     var option = document.createElement("option");
     option.value = "none";
     option.innerHTML = "See all results:";
     locationSelect.appendChild(option);
   }*/

   /*function searchLocationsNear(center) {
     clearLocations();

     var radius = document.getElementById('radiusSelect').value;
     var searchUrl = 'phpsqlsearch_genxml.php?lat=' + center.lat() + '&lng=' + center.lng() + '&radius=' + radius;
     downloadUrl(searchUrl, function(data) {
       var xml = parseXml(data);
       var markerNodes = xml.documentElement.getElementsByTagName("marker");
       var bounds = new google.maps.LatLngBounds();
       for (var i = 0; i < markerNodes.length; i++) {         
var name = markerNodes[i].getAttribute("name");         
var address = markerNodes[i].getAttribute("address");         
var distance = parseFloat(markerNodes[i].getAttribute("distance"));         
var latlng =new google.maps.LatLng(
parseFloat(markerNodes[i].getAttribute("lat")),
parseFloat(markerNodes[i].getAttribute("lng")));         

createOption(name, distance, i);
createMarker(latlng, name, address);
bounds.extend(latlng);       
}
map.fitBounds(bounds);
locationSelect.style.visibility ="visible";
locationSelect.onchange =function(){         
var markerNum = locationSelect.options[locationSelect.selectedIndex].value;
google.maps.event.trigger(markers[markerNum],'click');       
};      
});    
}    */
            
              


   

			  /*var marker = new google.maps.Marker({
			  position: new google.maps.LatLng(51.596490,-0.109514),
			  map: map,
			   <!--icon: mark,
			   <!--title:"End point!",
			   <!--animation: google.maps.Animation.BOUNCE
			});*/

        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(-33.863276, 151.207977),
          zoom: 12
        });
        var infoWindow = new google.maps.InfoWindow;

          // Change this depending on the name of your PHP or XML file
                //https://shemalesonly000.myartsonline.com/gmappan/map.php
          downloadUrl('https://shemalesonly000.myartsonline.com/gmappan/xml2.php', function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('id');
              var name = markerElem.getAttribute('name');
              var address = markerElem.getAttribute('address');
              var type = markerElem.getAttribute('type');
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

              var infowincontent = document.createElement('div');
              var strong = document.createElement('strong');
              strong.textContent = name
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));

              var text = document.createElement('text');
              text.textContent = address
              infowincontent.appendChild(text);
              mark = 'img/mark.png';
			  flag = 'img/flag.png';
              var icon = customLabel[type] || {};
              if (type=="restaurant") {
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label,
              });
              }
                    /*echo "var marker = new google.maps.Marker({
			  	      position:".$coordinates[$i]."
			  	      map: map,
                      icon: mark,
			  		  });";
                      //echo "var infowindow = new google.maps.InfoWindow();";
                      // echo "google.maps.event.addListener(marker, 'click', function() {
            			//infoWindow.setContent(html);
            			//infoWindow.open(map, marker);
          				//});";
                      $i++;*/
              if (type=="bar") {
              var marker = new google.maps.Marker({
                 map: map,
                 position: point,
                 label:icon.label
              });
              }
                  if (type=="uskonto") {
              var marker = new google.maps.Marker({
                 map: map,
                 position: point,
                         label: { text: "religion",
                         color: "#4682B4", 
                         fontSize: "30px",
                         fontWeight: "bold"
    					 },
              });
              }    
              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            });
          });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
    </script>
<script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-dFHYjTqEVLndbN2gdvXsx09jfJHmNc8&callback=initMap"
      defer
    ></script>
  </body>
</html>