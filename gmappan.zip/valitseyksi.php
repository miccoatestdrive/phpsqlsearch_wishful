<form action="xml.php">
 <input type="text" name"test">
 <input type="submit">
</form>
