<?php

// Opens a connection to a MySQL server.
$servername = "fdb30.awardspace.net";
	$username = "4205662_datab";
	$password = "ekmiekmi45";
	$dbname = "4205662_datab";
$connection=mysqli_connect ($servername, $username, $password,$dbname);
if (!$connection) {
    die('Not connected : ' . mysqli_connect_error());
}
?>