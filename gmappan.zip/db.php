<?php

$servername = "fdb30.awardspace.net";
	$username = "4205662_datab";
	$password = "ekmiekmi45";
	$dbname = "4205662_datab";
$conn=new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error){
	die("Connection Failed".$conn->connect_error);
}else{
	//echo "connected";
}

?>